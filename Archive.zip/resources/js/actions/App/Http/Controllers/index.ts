import TimeTicketController from './TimeTicketController'
import Settings from './Settings'

const Controllers = {
    TimeTicketController: Object.assign(TimeTicketController, TimeTicketController),
    Settings: Object.assign(Settings, Settings),
}

export default Controllers