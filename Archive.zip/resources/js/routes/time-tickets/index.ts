import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../wayfinder'
/**
* @see \App\Http\Controllers\TimeTicketController::create
* @see app/Http/Controllers/TimeTicketController.php:21
* @route '/time-tickets/create'
*/
export const create = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(options),
    method: 'get',
})

create.definition = {
    methods: ["get","head"],
    url: '/time-tickets/create',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\TimeTicketController::create
* @see app/Http/Controllers/TimeTicketController.php:21
* @route '/time-tickets/create'
*/
create.url = (options?: RouteQueryOptions) => {
    return create.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\TimeTicketController::create
* @see app/Http/Controllers/TimeTicketController.php:21
* @route '/time-tickets/create'
*/
create.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\TimeTicketController::create
* @see app/Http/Controllers/TimeTicketController.php:21
* @route '/time-tickets/create'
*/
create.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: create.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\TimeTicketController::create
* @see app/Http/Controllers/TimeTicketController.php:21
* @route '/time-tickets/create'
*/
const createForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: create.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\TimeTicketController::create
* @see app/Http/Controllers/TimeTicketController.php:21
* @route '/time-tickets/create'
*/
createForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: create.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\TimeTicketController::create
* @see app/Http/Controllers/TimeTicketController.php:21
* @route '/time-tickets/create'
*/
createForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: create.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

create.form = createForm

/**
* @see \App\Http\Controllers\TimeTicketController::store
* @see app/Http/Controllers/TimeTicketController.php:31
* @route '/time-tickets'
*/
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/time-tickets',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\TimeTicketController::store
* @see app/Http/Controllers/TimeTicketController.php:31
* @route '/time-tickets'
*/
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\TimeTicketController::store
* @see app/Http/Controllers/TimeTicketController.php:31
* @route '/time-tickets'
*/
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\TimeTicketController::store
* @see app/Http/Controllers/TimeTicketController.php:31
* @route '/time-tickets'
*/
const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\TimeTicketController::store
* @see app/Http/Controllers/TimeTicketController.php:31
* @route '/time-tickets'
*/
storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(options),
    method: 'post',
})

store.form = storeForm

/**
* @see \App\Http\Controllers\TimeTicketController::update
* @see app/Http/Controllers/TimeTicketController.php:54
* @route '/time-tickets/{timeTicket}'
*/
export const update = (args: { timeTicket: number | { id: number } } | [timeTicket: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(args, options),
    method: 'patch',
})

update.definition = {
    methods: ["patch"],
    url: '/time-tickets/{timeTicket}',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\TimeTicketController::update
* @see app/Http/Controllers/TimeTicketController.php:54
* @route '/time-tickets/{timeTicket}'
*/
update.url = (args: { timeTicket: number | { id: number } } | [timeTicket: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { timeTicket: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { timeTicket: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            timeTicket: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        timeTicket: typeof args.timeTicket === 'object'
        ? args.timeTicket.id
        : args.timeTicket,
    }

    return update.definition.url
            .replace('{timeTicket}', parsedArgs.timeTicket.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\TimeTicketController::update
* @see app/Http/Controllers/TimeTicketController.php:54
* @route '/time-tickets/{timeTicket}'
*/
update.patch = (args: { timeTicket: number | { id: number } } | [timeTicket: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(args, options),
    method: 'patch',
})

/**
* @see \App\Http\Controllers\TimeTicketController::update
* @see app/Http/Controllers/TimeTicketController.php:54
* @route '/time-tickets/{timeTicket}'
*/
const updateForm = (args: { timeTicket: number | { id: number } } | [timeTicket: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: update.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PATCH',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\TimeTicketController::update
* @see app/Http/Controllers/TimeTicketController.php:54
* @route '/time-tickets/{timeTicket}'
*/
updateForm.patch = (args: { timeTicket: number | { id: number } } | [timeTicket: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: update.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PATCH',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

update.form = updateForm

/**
* @see \App\Http\Controllers\TimeTicketController::show
* @see app/Http/Controllers/TimeTicketController.php:68
* @route '/time-tickets/{timeTicket}'
*/
export const show = (args: { timeTicket: number | { id: number } } | [timeTicket: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/time-tickets/{timeTicket}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\TimeTicketController::show
* @see app/Http/Controllers/TimeTicketController.php:68
* @route '/time-tickets/{timeTicket}'
*/
show.url = (args: { timeTicket: number | { id: number } } | [timeTicket: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { timeTicket: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { timeTicket: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            timeTicket: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        timeTicket: typeof args.timeTicket === 'object'
        ? args.timeTicket.id
        : args.timeTicket,
    }

    return show.definition.url
            .replace('{timeTicket}', parsedArgs.timeTicket.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\TimeTicketController::show
* @see app/Http/Controllers/TimeTicketController.php:68
* @route '/time-tickets/{timeTicket}'
*/
show.get = (args: { timeTicket: number | { id: number } } | [timeTicket: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\TimeTicketController::show
* @see app/Http/Controllers/TimeTicketController.php:68
* @route '/time-tickets/{timeTicket}'
*/
show.head = (args: { timeTicket: number | { id: number } } | [timeTicket: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\TimeTicketController::show
* @see app/Http/Controllers/TimeTicketController.php:68
* @route '/time-tickets/{timeTicket}'
*/
const showForm = (args: { timeTicket: number | { id: number } } | [timeTicket: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\TimeTicketController::show
* @see app/Http/Controllers/TimeTicketController.php:68
* @route '/time-tickets/{timeTicket}'
*/
showForm.get = (args: { timeTicket: number | { id: number } } | [timeTicket: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\TimeTicketController::show
* @see app/Http/Controllers/TimeTicketController.php:68
* @route '/time-tickets/{timeTicket}'
*/
showForm.head = (args: { timeTicket: number | { id: number } } | [timeTicket: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

show.form = showForm

/**
* @see \App\Http\Controllers\TimeTicketController::download
* @see app/Http/Controllers/TimeTicketController.php:88
* @route '/time-tickets/{timeTicket}/download'
*/
export const download = (args: { timeTicket: number | { id: number } } | [timeTicket: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: download.url(args, options),
    method: 'get',
})

download.definition = {
    methods: ["get","head"],
    url: '/time-tickets/{timeTicket}/download',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\TimeTicketController::download
* @see app/Http/Controllers/TimeTicketController.php:88
* @route '/time-tickets/{timeTicket}/download'
*/
download.url = (args: { timeTicket: number | { id: number } } | [timeTicket: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { timeTicket: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { timeTicket: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            timeTicket: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        timeTicket: typeof args.timeTicket === 'object'
        ? args.timeTicket.id
        : args.timeTicket,
    }

    return download.definition.url
            .replace('{timeTicket}', parsedArgs.timeTicket.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\TimeTicketController::download
* @see app/Http/Controllers/TimeTicketController.php:88
* @route '/time-tickets/{timeTicket}/download'
*/
download.get = (args: { timeTicket: number | { id: number } } | [timeTicket: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: download.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\TimeTicketController::download
* @see app/Http/Controllers/TimeTicketController.php:88
* @route '/time-tickets/{timeTicket}/download'
*/
download.head = (args: { timeTicket: number | { id: number } } | [timeTicket: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: download.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\TimeTicketController::download
* @see app/Http/Controllers/TimeTicketController.php:88
* @route '/time-tickets/{timeTicket}/download'
*/
const downloadForm = (args: { timeTicket: number | { id: number } } | [timeTicket: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: download.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\TimeTicketController::download
* @see app/Http/Controllers/TimeTicketController.php:88
* @route '/time-tickets/{timeTicket}/download'
*/
downloadForm.get = (args: { timeTicket: number | { id: number } } | [timeTicket: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: download.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\TimeTicketController::download
* @see app/Http/Controllers/TimeTicketController.php:88
* @route '/time-tickets/{timeTicket}/download'
*/
downloadForm.head = (args: { timeTicket: number | { id: number } } | [timeTicket: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: download.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

download.form = downloadForm

const timeTickets = {
    create: Object.assign(create, create),
    store: Object.assign(store, store),
    update: Object.assign(update, update),
    show: Object.assign(show, show),
    download: Object.assign(download, download),
}

export default timeTickets